# ProjectSend installers

One-command installers for [ProjectSend](https://www.projectsend.org) on Debian,
maintained by [Mountaineer IT](https://mountaineerit.com).

Two scripts live here because ProjectSend is currently two different
applications. Pick deliberately — they are not interchangeable.

| | [`install-projectsend2.sh`](install-projectsend2.sh) | [`legacy/install-projectsend-legacy.sh`](legacy/install-projectsend-legacy.sh) |
|---|---|---|
| Installs | **ProjectSend 2.x** (Laravel rewrite) | ProjectSend **legacy** (r-series) |
| Web server | **nginx** + PHP-FPM | Apache + mod_php |
| PHP | 8.4+ | 8.2+ |
| Database | MariaDB, **utf8mb4** | MariaDB, utf8 |
| Config | `.env` | `includes/sys.config.php` |
| Web root | `public/` subdirectory | install directory |
| Uploads stored | outside the web root | inside the web root |
| Status | **Current — use this** | Maintenance only |

---

## Quick start — ProjectSend 2.x

On a fresh Debian 12 or 13 server, as root or with sudo:

```sh
curl -fsSL https://raw.githubusercontent.com/MountaineerIT/ProjectSend/main/install-projectsend2.sh | sudo bash
```

Or download and read it first, which is the sensible habit for anything piped
into a root shell:

```sh
curl -fsSLO https://raw.githubusercontent.com/MountaineerIT/ProjectSend/main/install-projectsend2.sh
less install-projectsend2.sh
chmod +x install-projectsend2.sh && sudo ./install-projectsend2.sh
```

The script prompts for the public URL, the reverse-proxy address, the listen
port, and the database name, username and password. Press Enter at any prompt to
take the default shown. Prompts are read from `/dev/tty`, so they work correctly
even when the script arrives over a pipe from `curl`.

---

## Read this before installing 2.x

### nginx is mandatory. Apache cannot serve this application.

This is not a preference and there is no configuration that works around it.

In 2.x, uploaded files live in `storage/app/files/`, outside the web root, where
no URL can reach them. Every download therefore has to pass a permission check
in PHP, which then answers with an empty response carrying an `X-Accel-Redirect`
header telling nginx which file to stream. nginx serves it with the same code
path it uses for any static file — byte ranges, resume support, no PHP process
held open for the duration of a 5 GB download.

Apache's nearest equivalent, `mod_xsendfile`, reads a differently named header
(`X-Sendfile`) that ProjectSend does not send. On Apache the application installs
cleanly and every page works — you can log in, upload, manage clients, browse the
library — but **every download returns an empty response or a 404**. The failure
is silent until someone tries to download something.

If nginx is genuinely impossible on your hosting, the two supported escapes are
putting nginx in front of Apache as a reverse proxy, or moving file storage to
S3-compatible object storage so the web server is not involved in downloads at
all. Decide that before people start uploading, not after.

### 2.x is not an in-place upgrade from the legacy line

Install it fresh, then import. Upstream ships the importer as
`projectsend/v1-migration-tool`, which is a **private repository** — you will
need a `vcs` entry and credentials in composer to install it.

Not carried across by the migration: files encrypted at rest, files already on
S3/GCS/Azure, 2FA secrets, email templates, hidden assignments, and thumbnails.
Clients also switch from username-based to email-based login, and duplicate email
addresses will block the import. Scope this before migrating anyone.

---

## What the 2.x installer does

It provisions nginx, PHP 8.4 with FPM, and MariaDB, then configures the
application end to end.

On PHP: ProjectSend 2.x requires 8.4 or newer for both the CLI and FPM. Debian 12
ships 8.2, so the script adds the Sury repository there — with the signing key
scoped to that one repository via `signed-by`, rather than dropped into
`/etc/apt/trusted.gpg.d/` where it would be trusted to sign packages for every
repository on the system including Debian's own. Debian 13 already ships 8.4 and
no third-party repository is added. All 19 required extensions are verified after
install and the script aborts by name if any is missing. That includes `ldap`,
which is required **even if you never use LDAP** — a dependency declares it and
PHP refuses to start the app without it.

On the database: MariaDB is installed and locked down (anonymous accounts
dropped, `test` database removed, bound to `127.0.0.1`), and the application
database is created with **utf8mb4 / utf8mb4_unicode_ci**, which 2.x requires and
the legacy line did not use. Credentials are verified through a mode-600
`--defaults-extra-file` rather than being passed on the command line, where they
would be readable by any local user through the process table.

On the download: the release archive is fetched from GitHub and its published
SHA-256 is **verified before extraction**, aborting on mismatch. The asset is
selected by filename pattern rather than by position in the release's asset
array, so reordering or adding assets upstream cannot cause the wrong artifact to
be installed. Pin a specific release with `PS_VERSION=v2.0.0` if you want the
installed version to be the one you tested rather than whatever is newest.

On the application: `.env` is written, permissions are set, and `key:generate`,
`migrate --force` and `storage:link` are run as the web user. The nginx server
block points at `public/` and includes the `internal` `/protected-files/` block
that makes downloads work. A systemd queue worker and a per-minute scheduler cron
are installed.

Finally it runs health checks on every service, probes the app over HTTP, and
prints a recap — also saved to `/root/projectsend_credentials.txt` at mode 600.

### The worker and the cron are not optional

Sending email and building zip archives happen in the background. **Without the
queue worker, no email is ever sent and zip downloads never finish.** Without the
scheduler cron, expired files are never purged and Settings → Scheduler will show
that nothing has ever run. The installer sets up both; if you are reproducing
this by hand, do not skip them.

### Never run `php artisan config:cache` on this application

Nor `php artisan optimize`, which includes it.

Caching the configuration bakes every resolved setting into one file and the
framework stops reading `.env`. ProjectSend reads `TRUSTED_PROXIES` earlier than
that — straight from the environment, before the middleware stack is assembled —
so caching the config makes that read return nothing.

Nothing breaks loudly. The site comes up and everything looks fine. But behind a
proxy the app goes back to believing every visitor is the proxy: the login rate
limiter counts all of your users as one attacker and locks the whole site out
after five wrong passwords, and every row in the download log records the proxy's
address instead of the person who downloaded the file. Both surface weeks later
as a complaint.

The installer runs `route:cache`, `view:cache` and `event:cache`, which are safe,
and deliberately skips `config:cache`. If it has already been run,
`php artisan config:clear` fixes it immediately.

---

## Running behind a reverse proxy

The 2.x installer assumes a reverse proxy (BunkerWeb, nginx, an ALB, Cloudflare)
terminates TLS in front of the host. It therefore installs no certbot, has nginx
listen on plain HTTP on a port you choose, sets `SESSION_SECURE_COOKIE=true`, and
configures the firewall so only the proxy can reach the app port.

Point the proxy at `http://<server-ip>:<listen-port>`, forwarding
`X-Forwarded-For` and `X-Forwarded-Proto`, allowing request bodies of at least
your configured upload size, and with a proxy read timeout long enough for large
downloads.

`TRUSTED_PROXIES` is written to `.env` from the address you give at the prompt.
Do not leave it unset — see the `config:cache` section above for what goes wrong.

If you are **not** using a proxy and want TLS on this host directly, install
certbot after the run and let it edit the nginx config:

```sh
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d files.example.com
```

Then change `listen` back to `80` in `/etc/nginx/sites-available/projectsend.conf`
before running certbot, and set `APP_URL` in `.env` to the `https://` address.

---

## Environment overrides

Each of these skips the matching prompt.

| Variable | Default | Notes |
|---|---|---|
| `APP_DIR` | `/var/www/projectsend` | Web root becomes `$APP_DIR/public` |
| `APP_URL` | prompted | Public `https://` URL. Email links are built from this |
| `TRUSTED_PROXY` | prompted | IP or CIDR, comma-separated. `*` only if nothing but the proxy can reach the port |
| `LISTEN_ADDR` | `0.0.0.0` | Address nginx binds to |
| `LISTEN_PORT` | `8080` | Port the proxy connects to |
| `DB_NAME` / `DB_USER` | `projectsend` | Letters, digits, underscore |
| `DB_PASS` | prompted | Leave unset so it is prompted for and stays out of shell history |
| `PS_VERSION` | latest | Pin a release tag, e.g. `v2.0.0` |
| `MAX_UPLOAD` | `100M` | Also set this on your proxy |
| `NONINTERACTIVE` | unset | `=1` takes all defaults and generates a random DB password |

```sh
curl -fsSL https://raw.githubusercontent.com/MountaineerIT/ProjectSend/main/install-projectsend2.sh \
  | sudo APP_URL=https://files.example.com TRUSTED_PROXY=10.0.0.5 PS_VERSION=v2.0.0 bash
```

---

## After the install

Create the first administrator by opening the site in a browser — the first
visit is the setup screen — or from the shell:

```sh
sudo -u www-data php8.4 /var/www/projectsend/artisan projectsend:admin
```

**Back up `APP_KEY`.** It is printed in the recap and saved in
`/root/projectsend_credentials.txt`. Anything encrypted with it, including saved
mail server credentials, cannot be recovered without it.

Configure email from inside the app at **System → Settings → Email**, which has a
"send test email" button. The `MAIL_*` values in `.env` are only used until you
fill that screen in.

To confirm the worker and cron are alive, open **System → Settings → Scheduler**.
It lists every task, when it last ran, and whether it succeeded.

### Useful paths

```
/var/www/projectsend                     install directory
/var/www/projectsend/public              web root
/var/www/projectsend/.env                configuration
/var/www/projectsend/storage/app/files   uploads (outside the web root)
/etc/nginx/sites-available/projectsend.conf
/etc/systemd/system/projectsend-worker.service
/root/projectsend_credentials.txt        credentials + APP_KEY, mode 600
```

```sh
sudo systemctl status projectsend-worker      # queue worker
sudo crontab -u www-data -l                   # scheduler heartbeat
sudo journalctl -u projectsend-worker -f      # worker logs
```

---

## Troubleshooting

**Every page works but downloads return an empty response or a 404.** You are on
Apache, or the `/protected-files/` block is missing from the nginx config. See
the nginx section above.

**No email is ever sent, or zip downloads never complete.** The queue worker is
not running. `sudo systemctl status projectsend-worker`.

**Everyone is locked out of the login form at once, or every download log row
shows the same IP.** `TRUSTED_PROXIES` is unset in `.env`, or `config:cache` has
been run and is preventing it from being read. Run `php artisan config:clear`.

**The installer aborts on a checksum mismatch.** It is doing its job — the
download was corrupted or tampered with. Re-run it; if it fails again, do not
bypass the check.

**`Could not reach the GitHub release API`.** The unauthenticated API is rate
limited to 60 requests per hour per source IP. Deploying many hosts from behind
one NAT will hit it. Pin a version with `PS_VERSION` to avoid the lookup.

---

## Legacy installer

[`legacy/install-projectsend-legacy.sh`](legacy/install-projectsend-legacy.sh)
installs the r-series line on a LAMP stack. It is kept for existing deployments
only. New installs should use 2.x.

Known limitations, documented rather than fixed: uploaded files are stored inside
the web root and are protected only by a `.htaccess` file that ships in the
application archive, which the installer neither writes nor verifies — changing
`AllowOverride All` to `None` in the vhost, or migrating to nginx, exposes every
uploaded file by URL. The downloaded archive is not integrity-verified. Neither
script configures TLS on the host; put a proxy in front.

---

## Requirements

Debian 11, 12 or 13, a fresh host, and root. Both scripts are idempotent enough
to re-run: an existing install directory is moved aside to a timestamped `.bak`
before the new one is written.

## License

See [LICENSE](LICENSE). ProjectSend itself is licensed separately — see
[projectsend/projectsend](https://github.com/projectsend/projectsend).
